#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
  tsec = time(NULL);
  tstruct = localtime(&tsec);
  printf("%02d:%02d:%02d: %5d|", tstruct->tm_hour, tstruct->tm_min,
         tstruct->tm_sec, getpid());
  va_start(args, fmt);
  return vprintf(fmt, args);
}

void createBinaryTree(int depth, int max_depth) {
  if (depth >= max_depth)
    return;

  pid_t child1, child2;
  child1 = fork(); // 创建第一个子进程

  if (child1 < 0) {
    // 错误处理
    perror("fork");
    return;
  } else if (child1 == 0) {
    // 子进程执行的代码
    createBinaryTree(depth + 1, max_depth);
    return;
  } else {
    // 父进程执行的代码
    child2 = fork(); // 创建第二个子进程
    sleep(2);
    if (child2 < 0) {
      // 错误处理
      perror("fork");
      return;
    } else if (child2 == 0) {
      // 第二个子进程执行的代码
      createBinaryTree(depth + 1, max_depth);
      return;
    } else {
      // 父进程执行的代码
      tprintf("Parent PID: %d, Child1 PID: %d, Child2 PID: %d\n", getpid(),
              child1, child2);
      return;
    }
  }
}

int main() {
  int depth = 0;
  int max_depth = 5; // 二叉树的最大深度

  createBinaryTree(depth, max_depth);
  sleep(100);
  return 0;
}
