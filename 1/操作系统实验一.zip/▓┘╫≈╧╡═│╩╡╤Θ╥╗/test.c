#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
  pid_t pid;
  int count = 0;

  printf("Testing maximum number of processes...\n");

  while ((pid = fork()) != -1) {
    if (pid == 0) {
      // 子进程
      exit(0);
    } else {
      // 父进程
      count++;
      printf("Created process %d\n", count);
    }
  }

  printf("Maximum number of processes reached.\n");

  return 0;
}
