#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
  tsec = time(NULL);
  tstruct = localtime(&tsec);
  printf("%02d:%02d:%02d: %5d|", tstruct->tm_hour, tstruct->tm_min,
         tstruct->tm_sec, getpid());
  va_start(args, fmt);
  return vprintf(fmt, args);
}

int main() {
  pid_t pid;
  int i;

  tprintf("Parent process PID: %d\n", getpid());

  for (i = 0; i < 10; i++) {
    pid = fork();

    if (pid == -1) {
      printf("fork");
      exit(EXIT_FAILURE);
    } else if (pid == 0) {
      // 子进程
      tprintf("Child process PID: %d\n", getpid());
      tprintf("Child %d: Hello from Child %d process!\n", i + 1, i + 1);
      exit(EXIT_SUCCESS);
    }
  }

  // 父进程等待所有子进程结束
  for (i = 0; i < 10; i++) {
    wait(NULL);
  }

  tprintf("Parent process: All child processes have terminated. Program "
          "exiting.\n");

  return 0;
}