#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
  tsec = time(NULL);
  tstruct = localtime(&tsec);
  printf("%02d:%02d:%02d: %5d|", tstruct->tm_hour, tstruct->tm_min,
         tstruct->tm_sec, getpid());
  va_start(args, fmt);
  return vprintf(fmt, args);
}

int main() {
  pid_t pid1, pid2;
  tprintf("Parent forked the first process.\n");

  // 创建第一个子进程
  pid1 = fork();

  if (pid1 == -1) {
    // 错误处理
    perror("fork");
    exit(EXIT_FAILURE);
  } else if (pid1 == 0) {
    // 子进程1
    tprintf("Child 1 PID: %d\n", getpid());
    sleep(2);
    tprintf("Child 1: Hello from Child 1 process!\n");
    exit(EXIT_SUCCESS);
  } else {
    // Parent创建第二个子进程
    tprintf("Parent forked the second process.\n");
    pid2 = fork();

    if (pid2 == -1) {
      // 错误处理
      perror("fork");
      exit(EXIT_FAILURE);
    } else if (pid2 == 0) {
      // 子进程2
      tprintf("Child 2 PID: %d\n", getpid());
      tprintf("Child 2: Hello from Child 2 process!\n");
      exit(EXIT_SUCCESS);
    } else {
      // 父进程
      tprintf("Parent PID: %d\n", getpid());
      tprintf("Parent: Hello from Parent process!\n");

      // 等待子进程结束
      int status1, status2;
      waitpid(pid1, &status1, 0);
      waitpid(pid2, &status2, 0);

      // 打印子进程结束信息
      if (WIFEXITED(status1)) {
        tprintf("Child 1 terminated with status: %d\n", WEXITSTATUS(status1));
      }
      if (WIFEXITED(status2)) {
        tprintf("Child 2 terminated with status: %d\n", WEXITSTATUS(status2));
      }

      tprintf(
          "Parent: All child processes have terminated. Program exiting.\n");
    }
  }

  return 0;
}